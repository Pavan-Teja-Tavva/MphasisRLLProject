package com.booksWagon.stepDefinition;
//
//import io.cucumber.java.en.And;
//import io.cucumber.java.en.Given;
//import io.cucumber.java.en.Then;
//import io.cucumber.java.en.When;
//
public class BasicSearchSteps {
//	
//	@Given ("I am logged in and on the homepage")
//	public void I_am_logged_in_and_on_the_homepage() {
//		System.out.println("Inside step - Logged in and basic search 1");
//	}
//		
//	@When ("I enter {string} in the search bar")
//	public void I_enter_string_in_the_search_bar(String searchItem) {
//		System.out.println("Inside step - Logged in and basic search 2");
//	}
//	    
//	   
//	@And ("I click the search button") 
//	public void I_click_the_search_button() {
//	    System.out.println("Inside step - Logged in and basic search 3");
//	}
//	    
//	@Then ("I should see search results related to {string}")
//	public void I_should_see_search_results_related_to_string(String searchItem) {
//	    System.out.println("Inside step - Logged in and basic search 4");
//	}
//	    
//	@Then ("I should see a message")
//	public void I_should_see_a_message() {
//	    System.out.println("Inside step - Logged in and basic search 5");
//	}
//	    
//	@When ("I enter empty input in the search bar")
//	public void I_enter_empty_input_in_the_search_bar() {
//	    System.out.println("Inside step - I enter empty input in the search bar");
//	}
}
