package com.booksWagon.stepDefinition;
//
//import io.cucumber.java.en.And;
//import io.cucumber.java.en.Given;
//import io.cucumber.java.en.Then;
//import io.cucumber.java.en.When;
//
public class FilterSearchSteps {
//	
//	@Given ("I am logged in and on the homepage")
//	public void I_am_logged_in_and_on_the_homepage() {
//		System.out.println("Step Inside 1 - Filter Steps");
//	}
//    
//	@When ("I enter {string} in the search bar")
//	public void I_enter_string_in_the_search_bar() {
//		System.out.println("Step Inside 2 - Filter Steps");
//	}
//	
//    @And ("I click the search button")
//    public void I_click_the_search_button() {
//    	System.out.println("Step Inside 3 - Filter Steps");
//    }
//    
//    @Then ("I should see search results related to {string}")
//    public void I_should_see_search_results_related_to_string() {
//    	System.out.println("Step Inside 4 - Filter Steps");
//    }
//    @When ("I apply the filter {string}")
//    public void I_apply_the_filter_string() {
//    	System.out.println("Step Inside 5 - Filter Steps");
//    }
}
